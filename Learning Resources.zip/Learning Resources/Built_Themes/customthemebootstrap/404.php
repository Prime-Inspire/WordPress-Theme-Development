<?php get_header(); ?>

<section class="404-page  pt-5 pb-5">
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-lg-6 col-md-6">
                <h1 class="text-center">404 <br><small>Page Not Found</small></h1>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>