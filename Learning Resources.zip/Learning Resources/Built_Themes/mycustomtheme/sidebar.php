<?php if ( is_active_sidebar( 'home_sidebar' ) ) : ?>
    <?php dynamic_sidebar( 'home_sidebar' ); ?>
<?php endif; ?>